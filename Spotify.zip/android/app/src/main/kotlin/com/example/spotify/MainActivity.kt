package com.example.spotify

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
